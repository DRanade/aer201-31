#include "operationCode.h"

void runOp(unsigned char time[3], unsigned char *pTotalSupplied, unsigned char *pNumPoles, poleInfo *infoArr, volatile bool *pInt1P, volatile bool *pInt0P, unsigned char *opTime){
    INT1IE = 0;                     // disable sensor/keypad interrupt
    LATCbits.LATC5 = 1;             // shunt keypad (disable it)
    TRISB = 0b10101011;             // set motor pins to outputs
    *pTotalSupplied = 0;
    *pNumPoles = 0;
    int i;
    unsigned char firstIter = 0;                                                // demo purposes only
    unsigned char rampPos = 0;      // ramp position counter
    unsigned char pos = 0;          // position tick counter
    unsigned char posTurns = 0;     // position turn counter
    unsigned char procMode = 0;     // 0-Moving out     1-Base Detected
                                    // 2-Pole Detected  3-Tires Deployed
                                    // 4-Moving Back
    setupUART();
    dispOpProg();
    dispProcMode(procMode);
    __delay_ms(100);
    while(1){   // poll through machine operation. Emergency stop still works
        if (procMode == 0 || procMode == 3){       // state transition portion
                                    // we know that interrupt happened. 
                                    // time to change state
            if (*pInt0P){           // if base detected, move on to base detected
                *pInt0P = false;
                INT0IE = 0;
                procMode = 1;
                dispProcMode(procMode);
            } 
        } else if (procMode == 1){
            if (*pInt1P){     // a pole was detected                                                                // change to polling
                *pInt1P = false;
                INT1IE = 0;         // disable detector interrupt
                procMode = 2;
                dispProcMode(procMode);
            }
        }
        if (procMode == 0){         // moving out
            //                                                                                         tell arduino to move
            while(!TXIF | !TRMT){       // wait until transmit ready
                continue;
            }
            TXREG = 'O';    // capital O for out
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 1;
            unsigned char oldPosSig = PORTEbits.RE1;    // start counting position
            INT0IE = 1;             // enables the base detector
            while (*pInt0P == false){   // counts current position until base is detected
                lcd_home();
                printf("%05u",posTurns);
                if (oldPosSig != PORTEbits.RE1){
                    __delay_us(2);
                    if (oldPosSig != PORTEbits.RE1){
                        pos += 1;
                        if (pos == 20){                                                         // full turn happened
                            pos = 0;
                            posTurns+=10;                                     // demo purposes only - regular is posTurns++;
                            if (posTurns*20 > 4000){                                                       // put appropriate distance fcn
                                procMode = 4;
                                dispProcMode(procMode);                                         // we are at end
                                break;
                            }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        oldPosSig = oldPosSig ? 0 : 1 ;
                    }
                }
                    //                                                          // demo purposes only
                /*    
                    if ((PORTBbits.RB1 == 1) && (firstIter == 1)){                                                  // make it turn back through kpd
                        procMode = 4;
                        dispProcMode(procMode);
                        __delay_ms(2000);
                        break;
                    }
                    if (firstIter == 0){
                        firstIter = 1;
                        __delay_ms(1000);
                    }
                */
                    //                                                          // end demo section
            }
            __delay_ms(20);     // debounce sensor
            if (PORTBbits.RB0 == 1){
            //                                                                                         tell arduino to stop
                while(!TXIF | !TRMT){       // wait until transmit ready
                    continue;
                }
                TXREG = 'S';    // capital S for stop
                LATAbits.LATA5 = 0;
                LATDbits.LATD1 = 0;
            }
        } else if (procMode == 1){  // base detected. moving ramp out
            detectFeedback();       // shows feedback after detecting base
            dispProcMode(procMode);
            infoArr[*pNumPoles].id = *pNumPoles + 1;
            infoArr[*pNumPoles].pos = posTurns*20;                                                      // position calculation fcn
            INT1IE = 1;             // enables the pole detector
            LATAbits.LATA1 = 0;                                                                     // ramp direction out
            LATAbits.LATA3 = 1;     // ramp motor enable
__delay_ms(500);
LATAbits.LATA1 = 0;                                                                     // ramp direction out
LATAbits.LATA3 = 0;     // ramp motor enable
            unsigned char rampPosSig = PORTCbits.RC0;    // start counting position
            while (*pInt1P == false){                                                                               // debug
                if (rampPosSig != PORTCbits.RC0){
                    __delay_us(2);
                    if (rampPosSig != PORTCbits.RC0){
                        rampPos += 1;
                        rampPosSig = rampPosSig ? 0 : 1 ;       // flip it
                    }
                }
            }
            //                                                                                        // maybe add debounce
            LATAbits.LATA1 = 0;
            LATAbits.LATA3 = 0;     // code to stop the motor
            __delay_ms(10);                                                                             // delay to allow machine to stop
        } else if (procMode == 2){ // tire deploy
            unsigned char tireVar = 0;
            if (PORTBbits.RB3 == 0){
                __delay_ms(20);
                if (PORTBbits.RB3 == 0){
                    tireVar += 1;
                }
            }
            if (PORTBbits.RB5 == 0){
                __delay_ms(20);
                if (PORTBbits.RB5 == 0){
                    tireVar += 1;
                }
            }
            if (*pNumPoles == 0){       // follow algorithm and calc how many to deploy
                                        // this is first pole case
                tireVar = 2-tireVar;
                infoArr[*pNumPoles].tiresPresent = 2;
            } else if ((posTurns - (infoArr[*pNumPoles-1].pos)/20) < 15){ // within 30cm                     // update to calc position correctly in integration
                if (tireVar == 2){ tooManyTires(); continue; }
                tireVar = 1-tireVar;
                infoArr[*pNumPoles].tiresPresent = 1;
            } else {
                tireVar = 2-tireVar;
                infoArr[*pNumPoles].tiresPresent = 2;
            }                                                   // tireVar is now number we have to deploy
            tireDeploy(tireVar,(*pTotalSupplied)%2);    // deploy tires and update data variables
            infoArr[*pNumPoles].tiresSupp = tireVar;
            *pTotalSupplied += tireVar;
            lcdNorm();           // send LCD back into "operation in progress"
            dispProcMode(procMode);
            tireVar = 0;
            while (tireVar != infoArr[*pNumPoles].tiresPresent){    // confirm
                                                    // that tires have arrived
                tireVar = 0;
                if (PORTBbits.RB3 == 0){
                    __delay_ms(20);
                    if (PORTBbits.RB3 == 0){
                        tireVar += 1;
                    }
                }
                if (PORTBbits.RB5 == 0){
                    __delay_ms(20);
                    if (PORTBbits.RB5 == 0){
                        tireVar += 1;
                    }
                }
                __delay_ms(100);
            }
            *pNumPoles += 1;    // finally increments number of detected poles
            procMode = 3;
            dispProcMode(procMode);
            __delay_ms(2000);                                                   // only for demo
        } else if (procMode == 3){  // move forward while retracting ramp
                                    // and checking for base
            unsigned char distSinceBase = 0;
            // INT0IE = 1;             // enables the base detector                                     pre base detector
            //                                                                                         tell arduino to move
            while(!TXIF | !TRMT){       // wait until transmit ready
                continue;
            }
            TXREG = 'O';    // capital O for out
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 1;
            
            LATAbits.LATA1 = 1;                                                                         // ramp direction in
            LATAbits.LATA3 = 0;     // ramp motor enable
__delay_ms(500);
LATAbits.LATA1 = 0;                                                                     // ramp direction out
LATAbits.LATA3 = 0;     // ramp motor enable
            unsigned char rampPosSig = PORTCbits.RC0;    // start counting position
            unsigned char oldPosSig = PORTEbits.RE1;    // start counting position
            INT1IE = 1;
            while (rampPos > 0 && ((*pInt0P) == false)){
                if (rampPosSig != PORTCbits.RC0){
                    __delay_us(2);
                    if (rampPosSig != PORTCbits.RC0){
                        rampPos -= 1;
                        rampPosSig = rampPosSig ? 0 : 1 ;       // flip it
                    }
                }
                if (oldPosSig != PORTEbits.RE1){
                    __delay_us(2);
                    if (oldPosSig != PORTEbits.RE1){
                        pos += 1;
                        if (pos == 20){
                            pos = 0;
                            posTurns++; 
                            distSinceBase++;                                                        // If machine has travelled a certain distance, enable base detect
                            if (distSinceBase == 10){                                                       // Change this to appropriate param later per dist
                                INT0IE = 1;                                                 // this happens once we have cleared enough distance
                            }
                        }
                        oldPosSig = oldPosSig ? 0 : 1 ;
                    }
                }
            }
            if (rampPos <= 0){
                LATAbits.LATA1 = 0;
                LATAbits.LATA3 = 0;     // ramp motor disable
                procMode = 0;
                dispProcMode(procMode);
__delay_ms(500);
                continue;
            } else { __delay_ms(5); }      // debounce sensor
            if ((*pInt0P) == true){
            //                                                                                         tell arduino to stop
                LATAbits.LATA1 = 0;
                LATAbits.LATA3 = 0;
                while(!TXIF | !TRMT){       // wait until transmit ready
                    continue;
                }
                TXREG = 'S';    // capital S for stop
                LATAbits.LATA5 = 0;
                LATDbits.LATD1 = 0;
                procMode = 1;
            }
        } else if (procMode == 4){
            while(!TXIF | !TRMT){       // wait until transmit ready
                continue;
            }
            TXREG = 'I';    // capital I for in
            LATAbits.LATA5 = 1;
            LATDbits.LATD1 = 0;
            __delay_ms(2000);                                                   // only for demo
            unsigned char oldPosSig = PORTEbits.RE1;    // start counting position
            while (posTurns > 20){    // counts current position until back at start
                lcd_home();
                printf("%05u",posTurns);
                if (oldPosSig != PORTEbits.RE1){
                    __delay_us(2);
                    if (oldPosSig != PORTEbits.RE1){
                        pos -= 1;
                        if (pos == 00){                                                         // full turn happened
                            posTurns-=20;
                            pos = 20;
                        }
                        oldPosSig = oldPosSig ? 0 : 1 ;
                    }
                }
            }
            //                                                                                         tell arduino to stop
            while(!TXIF | !TRMT){       // wait until transmit ready
                continue;
            }
            TXREG = 'S';    // capital S for stop
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 0;
            
            // record end time
            unsigned char endTime[3];
            getTime(endTime);
            fixTime(endTime);
            if (endTime[2] > time[2]){  // checks to see if the hour has rolled over
                                        // it would otherwise blow out of integer size
                endTime[2] -= 1;
                time[2] += 60;
            }
            *opTime = 60*endTime[1]+endTime[0] - 60*time[1] - time[0];
            return;
        }
    }
}

/*

// code for coprocessor:
    // set tris appropriately
    while (1){  // loops moving forwards and backwards forever
        unsigned int position = 0;
        unsigned int rClicks = 0;           // confirm we actually need ints for this
        unsigned char rRead = 0;
        unsigned int lClicks = 0;
        unsigned char lRead = 0;
        unsigned char motorDir = 0;
        unsigned char direction = 0;    // moving out
        // set both motor direction pins to 'outwards'
        while (position < 4000){
            if (COM1){                  // find out which pin is COM1
                // set both motor enable pins to 'on'
            } else {
                // set both motor enable pins to 'off'
            }
            // reading position on both encoders
            if (lRead != PORTCbits.RC4){    // has position of encoder changed?
                lRead = PORTCbits.RC4;      // update it
                // confirm direction by reading PORTCbits.RC0
                lClicks += 1;               // add click count
                if (lClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    lClicks = 0;
                    position += 1;
                    COM2 = ~COM2;           // so main processor knows position has ticked
                }
            }
            if (rRead != PORTCbits.RC5){    // has position of encoder changed?
                rRead = PORTCbits.RC5;      // update it
                rClicks += 1;               // add click count
                if (rClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    rClicks = 0;
                }
            }
            // compare rClicks with lClicks and use PWM to change the enable outputs
            // so that both motors turn at the same speed
            // 
            // continue polling motor encoders and changing motor speeds actively
        }
        direction = 1;
        while (position >= 0){
            if (COM1){                  // find out which pin is COM1
                // set both motor enable pins to 'on'
            } else {
                // set both motor enable pins to 'off'
            }
            // reading position on both encoders
            if (lRead != PORTCbits.RC4){    // has position of encoder changed?
                lRead = PORTCbits.RC4;      // update it
                // confirm direction by reading PORTCbits.RC0
                lClicks += 1;               // add click count
                if (lClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    lClicks = 0;
                    position += 1;
                    COM2 = ~COM2;           // so main processor knows position has ticked
                }
            }
            if (rRead != PORTCbits.RC5){    // has position of encoder changed?
                rRead = PORTCbits.RC5;      // update it
                rClicks += 1;               // add click count
                if (rClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    rClicks = 0;
                }
            }
            // compare rClicks with lClicks and use PWM to change the enable outputs
            // so that both motors turn at the same speed
            // 
            // continue polling motor encoders and changing motor speeds actively
        }
    }

*/

/*
struct poleInfo {
    unsigned char id;
    int pos;
    unsigned char tiresSupp;
    unsigned char tiresPresent;
};
typedef struct poleInfo poleInfo; */

                                                                                            // show on LCD which processor mode for debugging