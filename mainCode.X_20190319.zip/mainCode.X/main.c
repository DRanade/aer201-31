// include pic things
#include "xc.h"
#include "stdio.h"
#include "stdbool.h"
#include "configBits.h"
#include "I2C.h"
#include "lcd.h"

// include subfiles
#include "operationCode.h"
#include "helpers.h"

volatile bool int1Pressed = false;          // interrupt thing
volatile bool int0Pressed = false;
unsigned char totalTime = 0;                // total time in seconds
unsigned char tiresSupp = 0;                // total tires supplied by machine
unsigned char poleCount = 0;                // total number of poles
unsigned char currPole = 0;                 // current pole on display
poleInfo poleInfoArr[15];                   // stores pole info
unsigned int position = 0;
unsigned char tick = 0;
unsigned char lastStored = 3;             // first bit zero means nothing stored yet
unsigned char logToShow = 0;

void main(void){
    ADCON1 = 0b00001111;            // Set all A/D ports to digital (pg. 222)
    INT1IE = 1;                     // Enable RB1 (keypad data) interrupt
    INT0IE = 0;                     // Enable Interrupt
    ei();                           // enable interrupts
    TRISA = 0b11000000;             // config pins as input or output
    TRISB = 0b11111011;
    TRISC = 0b01011101;
    TRISD = 0b00000000;
    TRISE = 0b00001110;
    LATDbits.LATD1 = 0;
    LATAbits.LATA5 = 0;
    LATAbits.LATA1 = 0;
    LATAbits.LATA3 = 0;
    LATCbits.LATC5 = 0;             // enable keypad (enable it)                                                //////////
                                                                                                    //////// ASSIGN UNUSED IO to ZERO
    initLCD();
    I2C_Master_Init(100000);        // this section shows standby screen
    unsigned char time[7];          // time read from RTC
    unsigned char startTimeInt[3];
    unsigned char dispMode = 0; 
    // 0-standby  1-running   2-doneMain  3-doneGen   
    // 4-donePoleDet  5-pageTurnLeft  6-pageTurnRight
    // 7-testAndDebug   8-showLogMain   9-showLogsSelect    10-logGeneral
    // 11-logPoleDet    12-logPageTurnLeft  13-logPageTurnRight
// testing data
unsigned char direction = 1;
unsigned char direction1 = 1;
unsigned char direction2 = 1;
unsigned int SMposition = 0;
// end testing data
    while(1){           // polling loop
                                                                                       // show logs
        if(int1Pressed){
            int1Pressed = false; // Clear the flag
            // Update the display state
            dispMode = dispStateTrans(((PORTB & 0xF0) >> 4),dispMode,startTimeInt,&direction1, &direction2, &logToShow, lastStored);
        }
        if (dispMode == 0){     // show start screen with time
            if (tick >= 50){
                showTime(time);
                tick = 0;
            }
            tick ++;
        } else if (dispMode == 1){  // show 'in progress scene'
            runOp(startTimeInt,&tiresSupp,&poleCount,poleInfoArr,&int1Pressed,&int0Pressed,&totalTime);
            dispOpProg();
            TRISB = 0b11111011;
            INT1IE = 1;
            LATCbits.LATC5 = 0;             // unshunt keypad (reenable it)
            storeLog(totalTime,poleCount,tiresSupp,poleInfoArr,&lastStored);
            dispMode = 2;
        } else if (dispMode == 2){  // show 'doneMain' and reset  current pole
            scrDoneMain();
            currPole = 0;
        } else if (dispMode == 3){  // show 'doneGen'
            scrDoneGen(totalTime,tiresSupp,poleCount);
        } else if (dispMode == 4){  // show pole details
            scrDonePoleDet(poleInfoArr,currPole);
        } else if (dispMode == 5){  // decrement current pole if possible
            if (currPole > 0){ currPole -= 1; } // and then display details
            dispMode = 4;
            scrDonePoleDet(poleInfoArr,currPole);
        } else if (dispMode == 6){  // increment current pole if possible
            if (currPole+1 < poleCount){ currPole += 1; }
            dispMode = 4;
            scrDonePoleDet (poleInfoArr,currPole);  // and then display details
        } else if (dispMode == 7){
            // dispSMsrun(direction1, direction2);
            dispSMrun(direction1, SMposition);
            runSM(direction1,&SMposition,&int1Pressed);  // run SM
            // runSMsControl(direction1,direction2,&int1Pressed);
        } else if (dispMode == 8){
            dispShowLogs();
        } else if (dispMode == 9){
            dispLogMain(logToShow);
            currPole = 0;
        } else if (dispMode == 10){
            dispLogGen(logToShow);
        } else if (dispMode == 11){
            dispLogPoleDet(logToShow, currPole);
        } else if (dispMode == 12){
            if (currPole > 0){ currPole -= 1; } // and then display details
            dispMode = 11;
            dispLogPoleDet(logToShow, currPole);
        } else if (dispMode == 13){
            if (currPole+1 < read_EEPROM(64*logToShow+1)){ currPole += 1; } // and then display details
            dispMode = 11;
            dispLogPoleDet(logToShow, currPole);
        } else if (dispMode == 14){
            LATAbits.LATA1 = 1;
            LATAbits.LATA3 = 0;
            __delay_ms(500);
            LATAbits.LATA1 = 0;
            LATAbits.LATA3 = 0;
            dispMode = 0;
        }
        __delay_ms(10);    // delay while polling
    }
}

void __interrupt() interruptHandler(void){
    if(INT1IF){     // Interrupt keypad handler
        int1Pressed = true;     // update status
        INT1IF = 0;         // clear flag
    }
    else if (INT0IF){    // other interrupt
        int0Pressed = true;
        INT0IF = 0;
    }
}