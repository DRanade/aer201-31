#include "lcdCode.h"

void showTime(unsigned char pTime[7]){
    // Reset RTC memory pointer
    I2C_Master_Start(); // Start condition
    I2C_Master_Write(0b11010000); // 7 bit RTC address + Write
    I2C_Master_Write(0x00); // Set memory pointer to seconds
    I2C_Master_Stop(); // Stop condition

    // Read current time
    I2C_Master_Start(); // Start condition
    I2C_Master_Write(0b11010001); // 7 bit RTC address + Read
    for(unsigned char i = 0; i < 6; i++){
        pTime[i] = I2C_Master_Read(ACK); // Read with ACK to continue reading
    }
    pTime[6] = I2C_Master_Read(NACK); // Final Read with NACK
    I2C_Master_Stop(); // Stop condition

    // Print received data on LCD
    lcd_home();
    printf("TEAM 31     TIRE");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("    %02x/%02x/%02x    ", pTime[6],pTime[5],pTime[4]); // Print date in YY/MM/DD
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("    %02x:%02x:%02x    ", pTime[2],pTime[1],pTime[0]); // HH:MM:SS
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("0:START   8:LOGS");
}

void scrDoneMain(void){
    lcd_home();
    printf("--RUN COMPLETE--");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("1: GENERAL INFO ");
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("2: POLE DETAILS ");
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("-----0:DONE-----");
}

void scrDoneGen(unsigned int time, unsigned char tireCount, unsigned char poles){
    lcd_home();
    printf("TOTAL TIME: %3ds",time);
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("TIRES SUPP:  %2d ",tireCount);
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("POLE COUNT:  %2d ",poles);
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("-----0:MENU-----");
}

void scrDonePoleDet(poleInfo poleData[15],int currPole){
    lcd_home();
    printf("POLE%1x POS: %1d.%02dm",
    poleData[currPole].id,poleData[currPole].pos/1000,(poleData[currPole].pos % 1000)/10);
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("TIRES SUPP:   %1d ",poleData[currPole].tiresSupp);
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("TIRES ON POLE:%1d ",poleData[currPole].tiresPresent);
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("<*   0:MENU   #>");
}

void dispOpProg(void){
    unsigned int i;
    lcd_home();
    printf("  THE OPERATION ");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("  IS CURRENTLY  ");
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("   IN PROGRESS  ");
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("                ");
/*
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
                            for (i=0; i<13; i++){                   // potential progress bar left in for demo
                                __delay_ms(250);
                                printf("-");
                            }
*/
}

void dispProcMode(unsigned char mode){
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("PROCESSOR MODE %x",mode);
}

void detectFeedback(void){
    lcd_home();
    printf("!!!!! POLE !!!!!");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("! SUCCESSFULLY !");
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("!   DETECTED   !");
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("!!!!!!!!!!!!!!!!");
    // make sound through speaker
}

void tooManyTires(void){
    lcd_home();
    printf("!!!!!ERROR!!!!!!");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("!  THIS  POLE  !");
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("! HAS TOO MANY !");
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("! TIRES ON IT  !");
    // make sound through speaker
}

void lcdNorm(void){
    lcd_home();
    printf("  THE OPERATION ");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("  IS CURRENTLY  ");
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("   IN PROGRESS  ");
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("                ");
}

void dispShowLogs(void){
    lcd_home();
    printf("CHOOSE WHICH LOG");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("TO SEE ( 1 - 4 )");
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("1:NEW      4:OLD");
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("-----0:DONE-----");
}

void dispLogMain(unsigned char log){
    if (read_EEPROM(log*64+1) > 128){
        lcd_home();
        printf("      ERROR      ");
        lcd_set_ddram_addr(LCD_LINE2_ADDR);
        printf(" NO  INFORMATION ");
        lcd_set_ddram_addr(LCD_LINE3_ADDR);
        printf("      STORED     ",read_EEPROM(log*64+1));
        lcd_set_ddram_addr(LCD_LINE4_ADDR);
        printf("-----0:MENU-----");
    } else {
        lcd_home();
        printf("--SHOWING  LOG--");
        lcd_set_ddram_addr(LCD_LINE2_ADDR);
        printf("1: GENERAL INFO ");
        lcd_set_ddram_addr(LCD_LINE3_ADDR);
        printf("2: POLE DETAILS ");
        lcd_set_ddram_addr(LCD_LINE4_ADDR);
        printf("-----0:DONE-----");
    }
}

void dispLogGen(unsigned char log){
    if (read_EEPROM(log*64+1) > 128){
        lcd_home();
        printf("      ERROR      ");
        lcd_set_ddram_addr(LCD_LINE2_ADDR);
        printf(" NO  INFORMATION ");
        lcd_set_ddram_addr(LCD_LINE3_ADDR);
        printf("      STORED     ",read_EEPROM(log*64+1));
        lcd_set_ddram_addr(LCD_LINE4_ADDR);
        printf("-----0:MENU-----");
    } else {
        lcd_home();
        printf("TOTAL TIME: %3ds", read_EEPROM(log*64));
        lcd_set_ddram_addr(LCD_LINE2_ADDR);
        printf("TIRES SUPP:  %2d ",read_EEPROM(log*64+2));
        lcd_set_ddram_addr(LCD_LINE3_ADDR);
        printf("POLE COUNT:  %2d ",read_EEPROM(log*64+1));
        lcd_set_ddram_addr(LCD_LINE4_ADDR);
        printf("-----0:MENU-----");
    }
}

void dispLogPoleDet(unsigned char log, unsigned char currPole){
    if (read_EEPROM(log*64+1) > 128){
        lcd_home();
        printf("      ERROR      ");
        lcd_set_ddram_addr(LCD_LINE2_ADDR);
        printf(" NO  INFORMATION ");
        lcd_set_ddram_addr(LCD_LINE3_ADDR);
        printf("      STORED     ",read_EEPROM(log*64+1));
        lcd_set_ddram_addr(LCD_LINE4_ADDR);
        printf("-----0:MENU-----");
    } else {
        if (read_EEPROM(log*64+1) == 0){
            lcd_home();
            printf("  THIS RUN HAD  ");
            lcd_set_ddram_addr(LCD_LINE2_ADDR);
            printf("    NO POLES    ");
            lcd_set_ddram_addr(LCD_LINE3_ADDR);
            printf("    DETECTED    ");
            lcd_set_ddram_addr(LCD_LINE4_ADDR);
            printf("-----0:MENU-----");
        } else {
            int pos = ((int)read_EEPROM(log*64+3+4*currPole))<<8 | (int)read_EEPROM(log*64+4+4*currPole);
            lcd_home();
            printf("POLE%1x POS: %1d.%02dm",
            currPole+1,(pos)/1000, (pos % 1000)/10);
            lcd_set_ddram_addr(LCD_LINE2_ADDR);
            printf("TIRES SUPP:   %1d ",read_EEPROM(log*64+5+4*currPole));
            lcd_set_ddram_addr(LCD_LINE3_ADDR);
            printf("TIRES ON POLE:%1d ",read_EEPROM(log*64+6+4*currPole));
            lcd_set_ddram_addr(LCD_LINE4_ADDR);
            printf("<*   0:MENU   #>");
        }
    }
}