#include "helpers.h"

void setupUART(void){
    long baudRate = 9600;
    SPBRG = (unsigned char)((_XTAL_FREQ / (64 * baudRate)) - 1);
    
    // Configure transmit control register
    TXSTAbits.TX9 = 0; // Use 8-bit transmission (8 data bits, no parity bit)
    TXSTAbits.SYNC = 0; // Asynchronous communication
    TXSTAbits.TXEN = 1; // Enable transmitter
    __delay_ms(5); // Enabling the transmitter requires a few CPU cycles for stability
    
    // Configure receive control register
    RCSTAbits.RX9 = 0; // Use 8-bit reception (8 data bits, no parity bit)
    RCSTAbits.CREN = 1; // Enable receiver
    
    // Enforce correct pin configuration for relevant TRISCx
    TRISCbits.TRISC6 = 0; // TX = output
    TRISCbits.TRISC7 = 1; // RX = input
   
    // Enable serial peripheral
    RCSTAbits.SPEN = 1;
}

void fixTime(unsigned char Time[]){
    Time[2] = ((Time[2])>>4)*10 + ((Time[2])&0x0F);
    Time[1] = ((Time[1])>>4)*10 + ((Time[1])&0x0F);
    Time[0] = ((Time[0])>>4)*10 + ((Time[0])&0x0F);
}

void getTime(unsigned char pTime[3]){
    // Reset RTC memory pointer
    I2C_Master_Start(); // Start condition
    I2C_Master_Write(0b11010000); // 7 bit RTC address + Write
    I2C_Master_Write(0x00); // Set memory pointer to seconds
    I2C_Master_Stop(); // Stop condition

    // Read current time
    I2C_Master_Start(); // Start condition
    I2C_Master_Write(0b11010001); // 7 bit RTC address + Read
    for(unsigned char i = 0; i < 2; i++){
        pTime[i] = I2C_Master_Read(ACK); // Read with ACK to continue reading
    }
    pTime[2] = I2C_Master_Read(NACK); // Final Read with NACK
    I2C_Master_Stop(); // Stop condition
}

void dispSMrun(char direc, unsigned int motorPos){
    lcd_home();
    printf(" STEPPER  MOTOR ");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf(" RUNNING DIR %s", (direc==1) ? "CCW\0":"CW \0"); // Print date in YY/MM/DD
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("%16x",motorPos);
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("1:SWITCH  D:STOP");
}

void dispSMsrun(char direc1, char direc2){
    lcd_home();
    printf(" STEPPER  MOTOR ");
    lcd_set_ddram_addr(LCD_LINE2_ADDR);
    printf("A DIR %s       ", (direc1==1) ? "CCW\0":"CW \0");
    lcd_set_ddram_addr(LCD_LINE3_ADDR);
    printf("B DIR %s       ", (direc2==1) ? "CCW\0":"CW \0");
    lcd_set_ddram_addr(LCD_LINE4_ADDR);
    printf("1:SWITCH  D:STOP");
}

unsigned char dispStateTrans(unsigned char keypress, unsigned char dispMode, unsigned char startTime[3], unsigned char *pStepDir1, unsigned char *pStepDir2, unsigned char* pLogToShow, unsigned char lastWritten){
    if (dispMode == 0){
        if (keypress == 0x0D){                           // start button press
            getTime(startTime);                              // gets start time
            fixTime(startTime);
            return 1;           // send from 'standby' to 'running'
        } else if (keypress == 0x0F){
            return 7;
        } else if (keypress == 0x09){
            return 8;
        } else if (keypress == 0x03){
            LATAbits.LATA1 = 1;
            LATAbits.LATA3 = 0;
            while (PORTCbits.RC0 == 0){
                continue;
            }
            LATAbits.LATA1 = 1;
            LATAbits.LATA3 = 1;
            __delay_ms(50);
            LATAbits.LATA1 = 0;
            LATAbits.LATA3 = 0;
            return 0;
        } else if (keypress == 0x07){
            LATAbits.LATA1 = 0;
            LATAbits.LATA3 = 1;
            __delay_ms(50);
            LATAbits.LATA1 = 1;
            LATAbits.LATA3 = 1;
            __delay_ms(50);
            LATAbits.LATA1 = 0;
            LATAbits.LATA3 = 0;
            return 0;
        } else if (keypress == 0x02){
            runSMA(0);
        } else if (keypress == 0x06){
            LATCbits.LATC5 = 1;
            TRISB = 0b10101011;
            runSMB(1);
            TRISB = 0b11111111;
            LATCbits.LATC5 = 0;
        }
    } else if (dispMode == 1){  // send from 'running' to 'doneMain'
        return 2;
    } else if (dispMode == 2){  // send from 'doneMain' 
        if (keypress == 0x00){  // to 'doneGenDetails'
            return 3;
        } else if (keypress == 0x01){   // to 'donePoleDetails'
            return 4;
        // Add reset (of motor)!
        } else if (keypress == 0x0D){   // to 'standby'
            return 0;
        }
    } else if (dispMode == 3){  // send from 'doneGenDetails'
        if (keypress == 0x0D){  // to 'doneMain'
            return 2;
        }
    } else if (dispMode == 4){  // send from 'donePoleDetails'
        if (keypress == 0xC){   // to <previousPole>
            return 5;
        } else if (keypress == 0x0D){   // to <nextPole>
            return 2;
        } else if (keypress == 0x0E){   // to 'doneMain'
            return 6;
        }
    } else if (dispMode == 7){
        if (keypress == 0x00){
            (*pStepDir1) = ((*pStepDir1) == 0) ? 1:0;
            return 7;
        } else if (keypress == 0x01){
            (*pStepDir2) = ((*pStepDir2) == 0) ? 1:0;
            return 7;
        } else {
            return 0;
        }
    } else if (dispMode == 8){
        if (keypress == 0){
            *pLogToShow = (lastWritten + 4)%4;
            return 9;
        } else if (keypress == 1){
            *pLogToShow = (lastWritten + 3)%4;
            return 9;
        } else if (keypress == 2){
            *pLogToShow = (lastWritten + 2)%4;
            return 9;
        } else if (keypress == 4){
            *pLogToShow = (lastWritten + 1)%4;
            return 9; 
        } else if (keypress == 0x0D){
            return 0;
        }
        return dispMode;
    } else if (dispMode == 9){  // send from 'doneMain' 
        if (keypress == 0x00){  // to 'doneGenDetails'
            return 10;
        } else if (keypress == 0x01){   // to 'donePoleDetails'
            return 11;
        // Add reset (of motor)!
        } else if (keypress == 0x0D){   // to 'standby'
            if (read_EEPROM((*pLogToShow)*64+1) > 128){
                return 8;
            }
            return 0;
        }
    } else if (dispMode == 10){  // send from 'doneGenDetails'
        if (keypress == 0x0D){  // to 'doneMain'
            return 9;
        }
    } else if (dispMode == 11){  // send from 'donePoleDetails'
        if (keypress == 0xC){   // to <previousPole>
            return 12;
        } else if (keypress == 0x0D){   // to <nextPole>
            return 9;
        } else if (keypress == 0x0E){   // to 'doneMain'
            return 13;
        }
    } else{
        return dispMode;        // invalid keypress > dispMode doesn't change
    }
    return dispMode;
}

void runSM(unsigned char direction, unsigned int *pSMposition, volatile bool *int1Pressed){
    unsigned char ticksA = 0;
    unsigned char hundreds = 1;
    while(1){
        if (direction == 0){ 
            ticksA = (ticksA+1)%8; 
            hundreds++;
            if (hundreds >= 100){
                (*pSMposition)++;
                hundreds = 0;
            }
        } else { 
            ticksA = (ticksA-1)%8; 
            hundreds--;
            if (hundreds <= 0){
                (*pSMposition)--;
                hundreds = 100;
                if ((PORTB & 0xF1) == 0x31){
                    if(*pSMposition <= 0xfe75){
                        break;
                    }
                }
            }
        }
        __delay_ms(0.7);
        if (ticksA == 0){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 1){
            LATA = (LATA & 0xEA) | 0x05;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 2){
            LATA = (LATA & 0xEA) | 0x04;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 3){
            LATA = (LATA & 0xEA) | 0x14;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 4){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 5){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 1;    
        } else if (ticksA == 6){
            LATA = (LATA & 0xEA) | 0x00;
            LATEbits.LATE0 = 1;
        } else if (ticksA == 7){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 1;
        }
        if (*int1Pressed){
            if ((PORTB & 0xF1) != 0x31){
                break;
            }
        }
    }
    while((PORTB & 0xF1) == 0x31){
        continue;
    }
}

void runSMA(unsigned char dirA){
    unsigned char subCtr = 0;
    unsigned char ctr = 0;
    unsigned char ticksA = 0;
    while(1){
        subCtr++;
        if (subCtr >= 40){
            subCtr = 0;
            ctr++;
        }
        __delay_ms(0.7);
        if (dirA == 0){ 
            ticksA = (ticksA+1)%8; 
        } else { 
            ticksA = (ticksA-1)%8; 
        }
        if (ticksA == 0){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 1){
            LATA = (LATA & 0xEA) | 0x05;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 2){
            LATA = (LATA & 0xEA) | 0x04;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 3){
            LATA = (LATA & 0xEA) | 0x14;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 4){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 5){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 1;    
        } else if (ticksA == 6){
            LATA = (LATA & 0xEA) | 0x00;
            LATEbits.LATE0 = 1;
        } else if (ticksA == 7){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 1;
        }
        if (ctr >= 197){
            return;
        }
    }
}

void runSMB(unsigned char dirB){
    unsigned char subCtr = 0;
    unsigned int ctr = 0;
    unsigned char ticksB = 0;
    while(1){
        subCtr++;
        if (subCtr >= 40){
            subCtr = 0;
            ctr++;
        }
        __delay_ms(0.7);
        if (dirB == 0){ 
            ticksB = (ticksB+1)%8; 
        } else { 
            ticksB = (ticksB-1)%8; 
        }
        if (ticksB == 0){
            LATB = (LATB & 0xAB) | 0x04;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 1){
            LATB = (LATB & 0xAB) | 0x14;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 2){
            LATB = (LATB & 0xAB) | 0x10;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 3){
            LATB = (LATB & 0xAB) | 0x50;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 4){
            LATB = (LATB & 0xAB) | 0x40;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 5){
            LATB = (LATB & 0xAB) | 0x40;
            LATDbits.LATD0 = 1;    
        } else if (ticksB == 6){
            LATB = (LATB & 0xAB) | 0x00;
            LATDbits.LATD0 = 1;
        } else if (ticksB == 7){
            LATB = (LATB & 0xAB) | 0x04;
            LATDbits.LATD0 = 1;
        }
        if (ctr >= 197){
            return;
        }
    }
}

void runSMs(unsigned char dirA, unsigned char dirB){
    unsigned char subCtr = 0;
    unsigned int ctr = 0;
    unsigned char ticksA = 0;
    unsigned char ticksB = 0;
    while(1){
        subCtr++;
        if (subCtr >= 40){
            subCtr = 0;
            ctr++;
        }
        __delay_ms(0.7);
        if (dirA == 0){ 
            ticksA = (ticksA+1)%8; 
        } else { 
            ticksA = (ticksA-1)%8; 
        }
        if (dirB == 0){ 
            ticksB = (ticksB+1)%8; 
        } else { 
            ticksB = (ticksB-1)%8; 
        }
        if (ticksA == 0){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 1){
            LATA = (LATA & 0xEA) | 0x05;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 2){
            LATA = (LATA & 0xEA) | 0x04;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 3){
            LATA = (LATA & 0xEA) | 0x14;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 4){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 5){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 1;    
        } else if (ticksA == 6){
            LATA = (LATA & 0xEA) | 0x00;
            LATEbits.LATE0 = 1;
        } else if (ticksA == 7){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 1;
        }
        if (ticksB == 0){
            LATB = (LATB & 0xAB) | 0x04;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 1){
            LATB = (LATB & 0xAB) | 0x14;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 2){
            LATB = (LATB & 0xAB) | 0x10;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 3){
            LATB = (LATB & 0xAB) | 0x50;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 4){
            LATB = (LATB & 0xAB) | 0x40;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 5){
            LATB = (LATB & 0xAB) | 0x40;
            LATDbits.LATD0 = 1;    
        } else if (ticksB == 6){
            LATB = (LATB & 0xAB) | 0x00;
            LATDbits.LATD0 = 1;
        } else if (ticksB == 7){
            LATB = (LATB & 0xAB) | 0x04;
            LATDbits.LATD0 = 1;
        }
        if (ctr >= 197){
            return;
        }
    }
}

void runSMsControl(unsigned char dirA, unsigned char dirB, volatile bool *int1Pressed){
    unsigned char ticksA;
    unsigned char ticksB;
    TRISB = 0b00001011;
    while(1){
        __delay_ms(0.7);
        if (dirA == 0){ 
            ticksA = (ticksA+1)%8; 
        } else { 
            ticksA = (ticksA-1)%8; 
        }
        if (dirB == 0){ 
            ticksB = (ticksB+1)%8; 
        } else { 
            ticksB = (ticksB-1)%8; 
        }
        if (ticksA == 0){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 1){
            LATA = (LATA & 0xEA) | 0x05;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 2){
            LATA = (LATA & 0xEA) | 0x04;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 3){
            LATA = (LATA & 0xEA) | 0x14;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 4){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 0;
        } else if (ticksA == 5){
            LATA = (LATA & 0xEA) | 0x10;
            LATEbits.LATE0 = 1;    
        } else if (ticksA == 6){
            LATA = (LATA & 0xEA) | 0x00;
            LATEbits.LATE0 = 1;
        } else if (ticksA == 7){
            LATA = (LATA & 0xEA) | 0x01;
            LATEbits.LATE0 = 1;
        }
        if (ticksB == 0){
            LATB = (LATB & 0xAB) | 0x04;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 1){
            LATB = (LATB & 0xAB) | 0x14;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 2){
            LATB = (LATB & 0xAB) | 0x10;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 3){
            LATB = (LATB & 0xAB) | 0x50;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 4){
            LATB = (LATB & 0xAB) | 0x40;
            LATDbits.LATD0 = 0;
        } else if (ticksB == 5){
            LATB = (LATB & 0xAB) | 0x40;
            LATDbits.LATD0 = 1;    
        } else if (ticksB == 6){
            LATB = (LATB & 0xAB) | 0x00;
            LATDbits.LATD0 = 1;
        } else if (ticksB == 7){
            LATB = (LATB & 0xAB) | 0x04;
            LATDbits.LATD0 = 1;
        }
        if (*int1Pressed){
            TRISB = 0b11111011;
            break;
        }
    }
}

void deployLeft(void){
    runSMA(1);
}

void deployRight(void){
    runSMB(0);
}

void deployBoth(void){
    runSMs(1,0);
}

void tireDeploy(unsigned char amount, unsigned char firstTank){
    if (amount == 0){
        return;
    }
    else if (amount == 1){
        if (firstTank == 1){    // 1 denotes left tank is first to deploy
            deployLeft();
        } else {
            deployRight();
        }
    } else {
        deployBoth();
    }
}






void write_EEPROM(unsigned char address, unsigned char data){
    while( EECON1bits.WR  ){continue;} //checking if not busy with an earlier write.

    EECON1bits.WREN=1; // Enable writing to EEPROM 
    EEADR=address; // load address 
    EEDATA=data; // load data
    EECON1bits.EEPGD=0; // access EEPROM memory
    EECON1bits.CFGS=0; // avoid access configuration registers
    INTCONbits.GIE=0; // disable interrupts for critical EEPROM write sequence
    // required sequence start
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;
    // required sequence end
    INTCONbits.GIE = 1; // enable interrupts, critical sequence complete
    while (EECON1bits.WR==1); // wait for write to complete
    EECON1bits.WREN=0;  // do not allow EEPROM writes
}

unsigned char read_EEPROM(unsigned char address){
    while( EECON1bits.WR  ){continue;} //checking if busy
    
    EEADR = address; // load address 
    EECON1bits.EEPGD = 0; // access EEPROM memory
    EECON1bits.CFGS  = 0; // avoid access configuration registers
    EECON1bits.RD    = 1; // read 
    return( EEDATA );
}

void shift_EEPROM(void){
    short int i;
    short int val = 0;
    
    for (i = 204; i >= 0; i--){ // shifting all values by 41 addresses in EEPROM 
        val = read_EEPROM(i);
        write_EEPROM(i+41, val);
    }
}

void storeLog(unsigned char time, unsigned char numPoles, unsigned char tiresDep, poleInfo* infoArr, unsigned char* pLastLog){
    unsigned char currAdr = 0;
    unsigned char i=0;
    unsigned char currLog = (*pLastLog+1)%4;
    *pLastLog = currLog;
    currAdr = currLog*64;
    write_EEPROM(currAdr,time);                         currAdr++;
    write_EEPROM(currAdr,numPoles);                     currAdr++;
    write_EEPROM(currAdr,tiresDep);                     currAdr++;
    while (1) {
        if ((i >= numPoles)&& (i < 15)) { break; }
        write_EEPROM(currAdr,((infoArr[i]).pos)>>8);    currAdr++;
        write_EEPROM(currAdr,((infoArr[i]).pos)&0xff);  currAdr++;
        write_EEPROM(currAdr,(infoArr[i]).tiresSupp);   currAdr++;
        write_EEPROM(currAdr,(infoArr[i]).tiresPresent);currAdr++;
        i++;
    }
}