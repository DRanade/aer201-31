#include "operationCode.h"

void runOp(unsigned char time[3], unsigned char *pTotalSupplied, unsigned char *pNumPoles, poleInfo *infoArr, volatile bool *pInt0P, unsigned char *opTime){
    INT0IE = 0;
    LATCbits.LATC5 = 1;             // shunt keypad (disable it)
    TRISB = 0b10101011;             // set motor pins to outputs
    *pTotalSupplied = 0;
    *pNumPoles = 0;
    int i;
    unsigned char firstIter = 0;                                                // demo purposes only
    unsigned char pos = 0;          // position tick counter
    unsigned char posTurns = -9;     // position turn counter
    unsigned char procMode = 0;     // 0-Moving out     1-Base Detected
                                    // 2-Pole Detected  3-Tires Deployed
                                    // 4-Moving Back
    unsigned char distBaseDet = 0;
//    setupUART();                                                                                                  no more UART
    *pInt0P = false;
    __delay_ms(100);
    dispProcMode(procMode);
    di();
    INT0IE = 1;
    ei();
    (*pInt0P) = false;
    while(1){   // poll through machine operation. Emergency stop still works
        if (procMode == 0 || procMode == 3){       // state transition portion
                                    // we know that interrupt happened. 
                                    // time to change state
            if (*pInt0P){           // if base detected, move on to base detected
                (*pInt0P) = false;
                __delay_ms(5);
                INT0IE = 0;
                procMode = 1;
                distBaseDet = 0;
                dispProcMode(procMode);
            } 
        }
        if (procMode == 0){         // moving out
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 1;
            LATCbits.LATC2 = 0;
            unsigned char oldPosSig = PORTEbits.RE1;    // start counting position
            INT0IE = 1;             // enables the base detector
            while (*pInt0P == false){   // counts current position until base is detected
                lcd_home();
                printf("%05u",posTurns);
                if (oldPosSig != PORTEbits.RE1){
                    __delay_us(20);
                    if (oldPosSig != PORTEbits.RE1){
                        if (pos >= 5){                                                         // full turn happened
                            pos = 0;
                            posTurns += 1;                                     // demo purposes only - regular is posTurns++;
                            if (posTurns == 118){                                                       // put appropriate distance fcn
                                procMode = 4;
                                dispProcMode(procMode);                                         // we are at end
                                break;
                            }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        pos += 1;
                        oldPosSig = oldPosSig ? 0 : 1 ;
                    }
                }
                    //                                                          // demo purposes only
                /*    
                    if ((PORTBbits.RB1 == 1) && (firstIter == 1)){                                                  // make it turn back through kpd
                        procMode = 4;
                        dispProcMode(procMode);
                        __delay_ms(2000);
                        break;
                    }
                    if (firstIter == 0){
                        firstIter = 1;
                        __delay_ms(1000);
                    }
                */
                    //                                                          // end demo section
            }
            /*
            __delay_ms(20);     // debounce sensor
            if (PORTBbits.RB0 == 1){
                LATAbits.LATA5 = 0;
                LATDbits.LATD1 = 0;
            }
            */
        } else if (procMode == 1){  // base detected. moving ramp out
            /*
             * if (distBaseDet == 0){
                LATAbits.LATA5 = 1;
                LATDbits.LATD1 = 1;
                unsigned char oldPosSig = PORTEbits.RE1;
                while (distBaseDet <= 5){
                    break;                                              // this line circumvents the base detect delay
                    lcd_home();
                    printf("     %05u",distBaseDet);
                    if (oldPosSig != PORTEbits.RE1){
                        __delay_us(20);
                        if (oldPosSig != PORTEbits.RE1){
                            if (pos == 10){                                                         // full turn happened
                                pos = 0;
                                posTurns+=1;                                     // demo purposes only - regular is posTurns++;
                            }
                            pos += 1;
                            distBaseDet += 1;
                            oldPosSig = oldPosSig ? 0 : 1 ;
                        }
                    }
                }
            }
            */
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 0;
            LATCbits.LATC2 = 1;
            detectFeedback();       // shows feedback after detecting base
            lcd_home();
            printf("%05u      %05u",posTurns,pos);
            dispProcMode(procMode);
            if (PORTCbits.RC0 == 0){        // if ramp not in, put it in
                LATAbits.LATA1 = 1;                                                                     // ramp direction in to reset position if neccessary
                LATAbits.LATA3 = 0;     // ramp motor enable
            }
            while (PORTCbits.RC0 == 0){
                continue;
            }
LATAbits.LATA1 = 0;                                                                     // ramp direction out
LATAbits.LATA3 = 0;     // ramp motor enable
//                                                                                        // maybe add debounce
            __delay_ms(10);                                                                             // delay to allow machine to stop
            LATAbits.LATA5 = 1;     // start nudging
            LATDbits.LATD1 = 1;
            unsigned char oldPosSig = PORTEbits.RE1;
            unsigned char origDetLoc = posTurns;
            while (1){             // while nudge sensor is off, nudge to nudge sensor
                if (PORTBbits.RB5 == 0){
                    __delay_ms(50);
                    if (PORTBbits.RB5 == 0){
                        break;
                    }
                }
                lcd_home();
                printf("%05u",posTurns);
                
                if (oldPosSig != PORTEbits.RE1){
                    __delay_us(20);
                    if (oldPosSig != PORTEbits.RE1){
                        if (pos >= 5){                                                         // full turn happened
                            pos = 0;
                            posTurns += 1;                                     // demo purposes only - regular is posTurns++;
                            if (posTurns >= (origDetLoc + 3)) { break; }
                            if (posTurns == 118){                                                       // put appropriate distance fcn
                                procMode = 4;
                                dispProcMode(procMode);                                         // we are at end
                                break;
                            }
                        }
                        pos += 1;
                        oldPosSig = oldPosSig ? 0 : 1 ;
                    }
                }
            }
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 0;
            if (PORTBbits.RB5 == 0){            // while nudge sensor on, debounce it
                __delay_ms(200);
                if (PORTBbits.RB5 == 0){
                    LATAbits.LATA5 = 1;         // nudge forward
                    LATDbits.LATD1 = 1;
                    while (1){             // if second sensor is still on, nudge forward
                        //if (PORTBbits.RB5 == 1){
                          //  __delay_ms(10);
                            //if (PORTBbits.RB5 == 1){        // if nudge sensor goes off, break
                              //  break;
                                if (PORTBbits.RB3 == 0){
                                    __delay_ms(10);
                                    if (PORTBbits.RB3 == 0){// if pole sensor comes on, break
                                        break;
                                    }
                                }
                            //}
                        //}
                        
                                if (PORTBbits.RB5 == 0){
                                    __delay_ms(100);
                                    if (PORTBbits.RB5 == 0){
                                        continue;
                                    }
                                }
                        
                        unsigned char oldPosSig = PORTEbits.RE1;
                        unsigned char distPoleDet = 0;
                        while (distPoleDet <= 1){
                            lcd_home();
                            printf("     %05u",distPoleDet);
                            if (PORTBbits.RB3 == 0){
                                __delay_ms(10);
                                if (PORTBbits.RB3 == 0){
                                    break;
                                }
                            }
                            if (oldPosSig != PORTEbits.RE1){
                                __delay_us(20);
                                if (oldPosSig != PORTEbits.RE1){
                                    if (pos == 5){
                                        pos = 0;
                                        posTurns+=1;
                                    }
                                    pos += 1;
                                    distPoleDet += 1;
                                    oldPosSig = oldPosSig ? 0 : 1 ;
                                }
                            }
                        }
                        break;
                        
                    }
                    LATAbits.LATA5 = 0;
                    LATDbits.LATD1 = 0;
                }
            }
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 0;
            LATAbits.LATA1 = 0;                                                                     // ramp direction out
            LATAbits.LATA3 = 1;     // ramp motor enable
            unsigned char temp = 0;
            unsigned int i = 0;
            unsigned char found = 0;            // found will be the number of arm/nudge cycles it has done. 100 means pole found
            while (found < 4){
                found += 1;
                temp = 0;
                i = 0;
                LATAbits.LATA1 = 1;
                LATAbits.LATA3 = 0;
                while (PORTCbits.RC0 == 0){
                    continue;
                }
                LATAbits.LATA5 = 1;     // nudge twice
                LATDbits.LATD1 = 1;
                __delay_ms(400);
                LATAbits.LATA5 = 0;
                LATDbits.LATD1 = 0;
                LATAbits.LATA1 = 0;                                                                     // ramp direction out
                LATAbits.LATA3 = 1;     // ramp motor enable
                while (1){
                    if (PORTBbits.RB3 == 0){
                        __delay_ms(50);
                        if (PORTBbits.RB3 == 0){
                            found = 100;
                            break;
                        }
                    }
                    temp++;
                    if (temp >= 0xff){
                        temp = 0;
                        i++;
                        if ((i >= 0x360) && (temp >= 0x00)){    // if no pole found
                            break;
                        }
                    }
                }
            }
            LATAbits.LATA1 = 0;
            LATAbits.LATA3 = 0;
            
            infoArr[*pNumPoles].id = *pNumPoles + 1;
            infoArr[*pNumPoles].pos = posTurns*34;                                                      // position calculation fcn
            
            if (found < 80){
                LATAbits.LATA1 = 1;
                LATAbits.LATA3 = 0;
                while (PORTCbits.RC0 == 0){
                    continue;
                }
                LATAbits.LATA1 = 0;
                LATAbits.LATA3 = 0;
                infoArr[*pNumPoles].tiresPresent = 1;
                infoArr[*pNumPoles].tiresSupp = 0;
                *pNumPoles += 1;
                procMode = 3;
                continue;
            }
            
            
            while(1){
                if (PORTBbits.RB3 == 0){     // a pole was detected
                    __delay_ms(10);
                    if (PORTBbits.RB3 == 0){
                        procMode = 2;
                        dispProcMode(procMode);
/*
                                                                                    __delay_ms(5000);
                                                                                    LATAbits.LATA1 = 1;
                                                                                    LATAbits.LATA3 = 0;
                                                                                    while (PORTCbits.RC0 == 0){
                                                                                        continue;   
                                                                                    }
                                                                                    procMode = 3;
                                                                                    LATCbits.LATC2 = 0;
                                                                                    *pInt0P = false;
                                                                                    dispProcMode(procMode);
 */
                        break;
                    }
                }
            }
        } else if (procMode == 2){ // tire deploy
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 0;
            LATCbits.LATC2 = 1;
            unsigned char tireVar = 0;
            if (PORTCbits.RC6 == 0){
                __delay_ms(500);
                if (PORTCbits.RC6 == 0){
                    tireVar = 2;
                }
            } else if (PORTBbits.RB1 == 1){                // one tire sensor
                __delay_ms(500);
                if (PORTBbits.RB1 == 1){
                    tireVar = 1;
                }
            }
            if (*pNumPoles == 0){       // follow algorithm and calc how many to deploy
                                        // this is first pole case
                tireVar = 2-tireVar;
                infoArr[*pNumPoles].tiresPresent = 2;
            } else if ((posTurns - (infoArr[*pNumPoles-1].pos)/34) < 7){ // within 30cm                     // update to calc position correctly in integration
                if (tireVar == 2){ tooManyTires(); continue; }
                tireVar = 1-tireVar;
                infoArr[*pNumPoles].tiresPresent = 1;
            } else {
                tireVar = 2-tireVar;
                infoArr[*pNumPoles].tiresPresent = 2;
            }                                                   // tireVar is now number we have to deploy
            tireDeploy(tireVar,(*pTotalSupplied)%2);    // deploy tires and update data variables
            infoArr[*pNumPoles].tiresSupp = tireVar;
            *pTotalSupplied += tireVar;
            lcdNorm();           // send LCD back into "operation in progress"
            dispProcMode(procMode);
                                                                                                                    // assume perfert deployyment
            if (tireVar != 0){
                __delay_ms(3000);
            }
                
            tireVar = 0;
            // the below loop does not actually run since we don't wait for tires to go
            while (0){//(tireVar != infoArr[*pNumPoles].tiresPresent){    // confirm
                                                    // that tires have arrived
                tireVar = 0;
                if (PORTBbits.RB1 == 1){                    // sensor 1
                    __delay_ms(20);
                    if (PORTBbits.RB1 == 1){
                        tireVar += 1;
                        __delay_ms(100);
                        if (PORTCbits.RC6 == 0){            // sensor 2
                            __delay_ms(20);
                            if (PORTCbits.RC6 == 0){
                                tireVar += 1;
                            }
                        }
                    }
                }
                __delay_ms(100);
            }
            *pNumPoles += 1;    // finally increments number of detected poles
            procMode = 3;
            dispProcMode(procMode);
        } else if (procMode == 3){  // move forward while retracting ramp
                                    // and checking for base
            unsigned char distSinceBase = 0;
            LATCbits.LATC2 = 0;
            
            LATAbits.LATA1 = 1;                                                                         // ramp direction in
            LATAbits.LATA3 = 0;     // ramp motor enable
            
            while(PORTCbits.RC0 == 0){
                continue;
            }
            
            LATAbits.LATA1 = 0;
            LATAbits.LATA3 = 0;     // ramp motor stop
            
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 1;
            
            unsigned char oldPosSig = PORTEbits.RE1;    // start counting position
            INT0IE = 0;
            while (1){
                lcd_home();
                printf("%05u",posTurns);
                if (oldPosSig != PORTEbits.RE1){
                    __delay_us(20);
                    if (oldPosSig != PORTEbits.RE1){
                        if (pos == 5){
                            pos = 0;
                            posTurns += 1; 
                            distSinceBase += 1;                                                        // If machine has travelled a certain distance, enable base detect
                            if (distSinceBase == 2){                                                       // Change this to appropriate param later per dist
                                INT0IE = 1;                                                 // this happens once we have cleared enough distance
                                INT1IF = 0;
                                lcd_home();
                                printf("Going back into 0");
                                LATAbits.LATA5 = 0;
                                LATDbits.LATD1 = 0;
                                *pInt0P = false;
                                procMode = 0;
                                dispProcMode(procMode);
                                break;
                            }
                        }
                        pos += 1;
                        oldPosSig = oldPosSig ? 0 : 1 ;
                    }
                }
            }
        } else if (procMode == 4){
            LATAbits.LATA5 = 1;
            LATDbits.LATD1 = 0;
            LATCbits.LATC2 = 0;
            posTurns -= 38;    // back to moon
            unsigned char oldPosSig = PORTEbits.RE1;    // start counting position
            while (posTurns > 0){    // counts current position until back at start
                lcd_home();
                printf("%05u",posTurns);
                if (oldPosSig != PORTEbits.RE1){
                    __delay_us(20);
                    if (oldPosSig != PORTEbits.RE1){
                        if (pos <= 00){                                                         // full turn happened
                            posTurns-=1;
                            pos = 5;
                        }
                        pos -= 1;
                        oldPosSig = oldPosSig ? 0 : 1 ;
                    }
                }
            }
            LATAbits.LATA5 = 0;
            LATDbits.LATD1 = 0;
            
            // record end time
            unsigned char endTime[3];
            getTime(endTime);
            fixTime(endTime);
            if (endTime[2] > time[2]){  // checks to see if the hour has rolled over
                                        // it would otherwise blow out of integer size
                endTime[2] -= 1;
                time[2] += 60;
            }
            *opTime = 60*endTime[1]+endTime[0] - 60*time[1] - time[0];
            return;
        }
    }
}

/*

// code for coprocessor:
    // set tris appropriately
    while (1){  // loops moving forwards and backwards forever
        unsigned int position = 0;
        unsigned int rClicks = 0;           // confirm we actually need ints for this
        unsigned char rRead = 0;
        unsigned int lClicks = 0;
        unsigned char lRead = 0;
        unsigned char motorDir = 0;
        unsigned char direction = 0;    // moving out
        // set both motor direction pins to 'outwards'
        while (position < 4000){
            if (COM1){                  // find out which pin is COM1
                // set both motor enable pins to 'on'
            } else {
                // set both motor enable pins to 'off'
            }
            // reading position on both encoders
            if (lRead != PORTCbits.RC4){    // has position of encoder changed?
                lRead = PORTCbits.RC4;      // update it
                // confirm direction by reading PORTCbits.RC0
                lClicks += 1;               // add click count
                if (lClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    lClicks = 0;
                    position += 1;
                    COM2 = ~COM2;           // so main processor knows position has ticked
                }
            }
            if (rRead != PORTCbits.RC5){    // has position of encoder changed?
                rRead = PORTCbits.RC5;      // update it
                rClicks += 1;               // add click count
                if (rClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    rClicks = 0;
                }
            }
            // compare rClicks with lClicks and use PWM to change the enable outputs
            // so that both motors turn at the same speed
            // 
            // continue polling motor encoders and changing motor speeds actively
        }
        direction = 1;
        while (position >= 0){
            if (COM1){                  // find out which pin is COM1
                // set both motor enable pins to 'on'
            } else {
                // set both motor enable pins to 'off'
            }
            // reading position on both encoders
            if (lRead != PORTCbits.RC4){    // has position of encoder changed?
                lRead = PORTCbits.RC4;      // update it
                // confirm direction by reading PORTCbits.RC0
                lClicks += 1;               // add click count
                if (lClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    lClicks = 0;
                    position += 1;
                    COM2 = ~COM2;           // so main processor knows position has ticked
                }
            }
            if (rRead != PORTCbits.RC5){    // has position of encoder changed?
                rRead = PORTCbits.RC5;      // update it
                rClicks += 1;               // add click count
                if (rClicks >= THRESHOLD){  // threshold tbd (equal to number of clicks in a millimeter)
                    rClicks = 0;
                }
            }
            // compare rClicks with lClicks and use PWM to change the enable outputs
            // so that both motors turn at the same speed
            // 
            // continue polling motor encoders and changing motor speeds actively
        }
    }

*/

/*
struct poleInfo {
    unsigned char id;
    int pos;
    unsigned char tiresSupp;
    unsigned char tiresPresent;
};
typedef struct poleInfo poleInfo; */

                                                                                            // show on LCD which processor mode for debugging